package cs389.team6;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class takePhotoActivity extends AppCompatActivity implements
        View.OnClickListener{

    private ImageView imageView;
    private static final int PERMISSION_CODE = 0;
    private static final int IMAGE_CAMERA = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_take_photo);

        initView();
    }

    private void initView(){
        Button button = findViewById(R.id.camera_botton_id);
        imageView = findViewById(R.id.show_photo_take_by_camera);
        button.setOnClickListener(this);
    }

    @Override
    public void onClick(View view){
        getCameraPermission();
    }

    private void getCameraPermission(){
        if(Build.VERSION.SDK_INT>=23){
            int checkPermission = ContextCompat.checkSelfPermission(
                    this, Manifest.permission.CAMERA
            );
            if(checkPermission != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.CAMERA},
                        PERMISSION_CODE);
                return;
            }else {
                openCamera();
            }
        }else {
            openCamera();
        }
    }

    //@Override
    protected void onRequestPermissionResult(int requestCode,
                                             String[] permissions,
                                             int[] grantResults){
        switch (requestCode){
            case PERMISSION_CODE:
                for(int i=0;i<grantResults.length;i++){
                    if(grantResults[i]==PackageManager.PERMISSION_GRANTED){
                        Toast.makeText(this ,
                                " get permission successfully",
                                Toast.LENGTH_LONG).show();
                        openCamera();
                    }else{
                        Toast.makeText(this,
                                "Failed to get permission",
                                Toast.LENGTH_LONG).show();
                    }
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode,
                        permissions,grantResults);
        }

    }

    private void openCamera() {
        /**
         * android.media.action.STILL_IMAGE_CAMERA
         * 会在拍摄后一直停留在相机界面
         */
        Intent cameraIntent =
                new Intent("android.media.action.IMAGE_CAPTURE");
        startActivityForResult(cameraIntent, IMAGE_CAMERA);
        //相机录音etc都用startActivityForResult
    }
    //@Override
    protected void onActivityResult(int requestCode,
                                    int resultCode,
                                    Intent data){
        super.onActivityResult(resultCode,resultCode,data);
        if(requestCode==IMAGE_CAMERA && resultCode==RESULT_OK){
            Log.i("camera","take photo successfully:"+requestCode);
            Bundle bundle = data.getExtras();
            Bitmap bitmap = (Bitmap) bundle.get("data");
            imageView.setImageBitmap(bitmap);
        }
    }
}